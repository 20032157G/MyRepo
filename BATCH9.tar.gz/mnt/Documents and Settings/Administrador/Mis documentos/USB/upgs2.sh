export x=`find /media /mnt -name "upgs2.sh" -print -quit` #---------------------------------------------- Busca la ruta de este bash

echo $(dirname "$x")	#--------------------------------------------------------------------------- Nos posicionamos en tal directorio
export x=$(dirname "$x")	#------------------------------------------------------------------- Creamos variable con tal ruta
if [ ! -d "$x"/HOME ]		#------------------------------------------------------------------- Existe home? Sino lo crea
then mkdir "$x"/HOME
fi
export HOME="$x"/HOME		#------------------------------------------------------------------- Creamos variable de la ruta home
#export PATH="$x"/HOME:$PATH	#------------------------------------------------------------------- Add path al la variable PATH
#echo $HOME		
#echo $PATH

#.....Configuring
#mount --bind "$HOME" /home	#------------------------------------------------------------------- Montamos HOME como home
#if [ ! -d "$HOME"/anaconda ]	#------------------------------------------------------------------- Esta anaconda dir? Sino ejecuta el bash ...
#then bash "$HOME"/Anaconda*.sh	
#fi
#echo PATH='$PATH':$(for (( i=1; i<=$(echo $PATH | awk -F':' '{print NF}'); i++ ));do if [ $i == $(echo $PATH |awk -F':' '{print NF}') ];then d=;else d=:;fi;echo $PATH |awk -F':' '{print "'$x'"$'$i'"'$d'"}';done) |sed 's/ //g' >> ~/.bashrc 



#......Updates
if [ "$x"/sources.list ]	#------------------------------------------------------------------- Existe archivo con repo?
then  
	cp "$x"/sources.list /etc/apt/ 	#----------------------------------------------------------- Reemplazamos el archivo con los repo de INTERNET
	if [ "$x"/updfls.tar.gz ]	#----------------------------------------------------------- Si existe previa descarga
	then
		tar -zxvf "$x"/updfls.tar.gz -C /var/lib/apt/lists --strip-components 4	#----------- Extraemos los archivos en su respectiva ruta
		#echo -e "\033#6 `cat /etc/*-release | egrep "^DISTRIB_CODE" | sed 's/^[^=]*=//'`"
		y="`cat /etc/*-release | egrep ^DISTRIB_CODE | sed 's/^[^=]*=//'`"
		echo -e "\e#6\e[103;34m$y\e[0m"
		if [ $y == "jaunty" ] 		
#if [ "`cat /etc/*-release | egrep ^DISTRIB_CODE | sed 's/^[^=]*=//'`" == "jaunty" ]#-Si estamos en la distribucion correcta, procede la operacion obtener llave
		then
			#Adding Public Key (Particular mode)
		#.........................................
			apt-key adv --recv-keys --keyserver keyserver.ubuntu.com 5A98F3BB4E5E17B5 
			apt-key adv --recv-keys --keyserver keyserver.ubuntu.com A6DCF7707EBC211F
			apt-key adv --recv-keys --keyserver keyserver.ubuntu.com EF4186FE247510BE
		else
			echo -e "\033#6\033[41;30mEsta distribucion no es `cat /etc/*-release |egrep "^DISTRIB_CODE"|sed 's/^[^=]*=//'`\033[0m"
		fi
		apt-get update	#------------------------------------------------------------------- Cargamos los repos a la Mem ROM
		rm "$x"/updfls.tar.gz	#----------------------------------------------------------- Borramos los archivos previamente descargados
	else
		apt-get update	#------------------------------------------------------------------- Cargamos los repos a la MEM ROM
	fi
	tar -cvzf  "$x"/updfls.tar.gz /var/lib/apt/lists/*.* 	#----------------------------------- Comprimimos los usados y posible nuevos

	#............................................


	#.....Upgrades...inconcluso
	#if [ "$x"/pkg1 ]
	#then
		#cp "$x"/pkg1/*.* "$HOME"/var/cache/apt/archives/ -i -n	#--------------------------- Copiamos los archivos previamente descargados de las actualizaciones e instalacion 
		#apt-get -o Dir="$HOME" -f -y install	#------------------------------------------- Asignamos la ruta de home para descargas
		#apt-get upgrade
		#cp "$HOME"/var/cache/apt/archives/*.* "$x"/pkg1/ -i -n
	#else
		#echo NO ENCUENTRO DESCARGAS
		#apt-get upgrade -y
		#cp "$HOME"/var/cache/apt/archives/*.* "$x"/pkg1/ -i -n
	#fi
	#apt-get clean
else
	echo NO ENCUENTRO EL ARCHIVO PREVIO 
fi

#............................................
#printf '\n'$x'aaa\n'	
y=$(find /media /mnt -name "anaconda2" -print -quit)
printf '\nPATH=$PATH:'$y/bin\n' >> ~/.bashrc	#----------------------------------- Add Path to bashrc file


