#BATCH update apt, listas de paquetes
res=$(find /media /mnt -name "upgs3.sh" -print -quit)
res=$(dirname "$res")
ID=$(cat /etc/*-release |sed -nr '/ID/p'|sed 's/^.*=//')
REL=$(cat /etc/*-release |sed -nr '/RELEASE/p'|sed 's/^.*=//')
COD=$(cat /etc/*-release |sed -nr '/CODE/p'|sed 's/^.*=//')

if [[ $ID = "Ubuntu" ]]
then
	if [ "$res"/DtCl.txt ]
	then
		n1=$(cat DtCl.txt|awk -F'\t' '{print $1}'|egrep "^[3-9]"|wc -l)	#tomo primera col # elementos
		r1=$(shuf -i 1-$n1 -n 1)	#randomize 1er numero
		e1=$(cat DtCl.txt|awk -F'\t' '{print $1}'|egrep "^[3-9]"|sed -n "$r1"p)	#Obtencion 1er elemento
		e=$(cat DtCl.txt|awk -F'\t' '{print $1}'|egrep "^[3-9]"|sed -n "$(( r1+1 ))"p)	#Elemento siguiente de la 1era fila
		R1=$(cat DtCl.txt|sed -n "/$e1\t/=")	#Posicion en la col 2 del elemt1
		R2=$(cat DtCl.txt|sed -n "/$e\t/=")	#Posicion en la col 2 del elemt2
		r2=shuf -i $R1-$R2 -n 1	#randomize 2do numero
		e2=$(cat DtCl.txt|sed -n "$r2"p|awk -F'\t' '{print $2}')	#Obtencion del 2do element
		echo -e "\e#6\e[1m\e[$((e1+10));${e2}m$ID\t$REL\t$COD\e[0m"	#Finalmente
	else
		echo -e "\e#6\e[1m\e[43;92m$ID\t$REL\tCOD\e[0m"
	fi
	if (( $(awk '{print $1*$2}'<<<"$REL 100") < 1200 ))
	then
		pwb=http://old-releases.ubuntu.com/ubuntu/
		rst=restricted
		sc=security
		un=universe
		ml=multiverse
		mn=main
		d=deb
		ds=$d-src
		pt=/etc/apt/sources.list
		echo $d $pwb $COD $mn $rst >> $pt
		echo $ds $pwb $COD $mn $rst >> $pt
		echo $d $pwb $COD-updates $mn $rst >> $pt
		echo $ds $pwb $COD-updates $mn $rst >> $pt
		echo $d $pwb $COD $un >> $pt
		echo $ds $pwb $COD $un >> $pt
		echo $d $pwb $COD-$sc $mn $rst >> $pt
		echo $ds $pwb $COD-$sc $mn $rst >> $pt
		echo $d $pwb $COD-$sc $un >> $pt
		echo $ds $pwb $COD-$sc $un >> $pt
		echo $d $pwb $COD $ml >> $pt
		echo $d $pwb $COD $ml >> $pt
		echo $d $pwb $COD-backports $mn $rst $un $ml >> $pt
	else
		echo La version acrtual es: 17, los repositorios cambian, en parte, posiblemente de: old-releases por: archive o por security.
	fi
else
	echo No es OS: Ubuntu, sera "\e#6\e[5m\e[44;31m$ID ?\e[0m"
fi
if [ "$res"/updfls.tar.gz ]
then
	tar -zxvf "$res"/updfls.tar.gz -C /var/lib/apt/lists
	apt-get update
	#rm "$res/updfls.tar.gz
else
	apt-get update
	cd /var/lib/apt/lists
	tar -zcvf $res/updfls.tar.gz *.*
fi
	
